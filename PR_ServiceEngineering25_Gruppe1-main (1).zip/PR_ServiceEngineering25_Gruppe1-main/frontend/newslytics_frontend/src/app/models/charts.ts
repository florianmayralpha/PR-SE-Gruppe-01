export interface PieChartItem {
	label: string;
	value: number;
	percentage: number;
}

export interface SectorAllocationResponse {
	portfolio_id: number;
	portfolio_name: string;
	total_value: number;
	allocation: PieChartItem[];
	message?: string;
}

export interface StockAllocationItem extends PieChartItem {
	isin: string;
}

export interface StockAllocationResponse {
	portfolio_id: number;
	portfolio_name: string;
	total_value: number;
	allocation: StockAllocationItem[];
}

export interface CountryAllocationItem {
	country: string;
	value: number;
	percentage: number;
}

export interface CountryAllocationResponse {
	portfolio_id: number;
	portfolio_name: string;
	total_value: number;
	results: CountryAllocationItem[];
}

export interface PerformanceDataPoint {
	date: string;
	total_value: number;
}

export interface StockPerformanceSeries {
	isin: string;
	symbol: string;
	name: string;
	series: {
		date: string;
		qty: number;
		value: number;
	}[];
}

export interface TransactionPerformance {
	tx_id: number;
	isin: string;
	symbol: string;
	kaufdatum: string;
	menge: number;
	kaufpreis: number;
	series: {
		date: string;
		value: number;
	}[];
}

export interface PerformanceLinechartResponse {
	portfolio_id: number;
	portfolio_name: string;
	range: string;
	start: string;
	end: string;
	interval: string;
	currency: string;
	series: PerformanceDataPoint[];
	per_stock: { [isin: string]: StockPerformanceSeries } | null;
	per_transaction: TransactionPerformance[] | null;
	positions_by_day?: any[] | null;
	meta: {
		mapped_symbols: number;
		isins: number;
		transactions_used: number;
		unresolved_count: number;
		unresolved: any[];
		note: string;
	};
}

export interface MarketDataPoint {
	datetime: string;
	open: number;
	high: number;
	low: number;
	close: number;
	volume: number | null;
}

export interface MarketDataResponse {
	symbol: string;
	range: string;
	interval: string;
	data: MarketDataPoint[];
}

export interface PortfolioPerformanceMeta {
	invested_total: number;
	prev_total_value: number;
	mapped_positions: number;
	missing_symbol: number;
	missing_price: number;
	note: string;
}

export interface PortfolioKPIs {
	portfolio_id: number;
	portfolio_name: string;
	total_value: number;
	absolute_return_eur: number;
	absolute_return_pct: number | null;
	daily_change_pct: number | null;
	currency: string;
	meta: PortfolioPerformanceMeta;
	positions?: any[];
}

export interface AggregatedPortfolioPerformanceResponse {
	user_id: number;
	portfolios_count: number;
	total_value: number;
	absolute_return_eur: number;
	absolute_return_pct: number | null;
	daily_change_pct: number | null;
	currency: string;
	portfolios: PortfolioKPIs[] | null;
	meta: PortfolioPerformanceMeta;
}
