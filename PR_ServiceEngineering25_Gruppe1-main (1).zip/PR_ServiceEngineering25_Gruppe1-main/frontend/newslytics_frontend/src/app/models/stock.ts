export interface Stock {
    id: number;
    name: string;
    isin: string;
    firma: string;
    ausschüttungsart?: string;
    kategorie?: string;
    land?: string;
    beschreibung?: string;
    ebitda?: number;
    nettogewinn?: number;
    umsatz?: number;
    currency?: string;
    unternehmenswert?: number;
}

export interface Transaction {
    id: number;
    menge: number;
    kaufpreis: number;
    kaufdatum: string;
    aktie_id: number;
    portfolio_id: number;
}

export interface StockQuote {
    symbol: string;
    ticker: string;
    isin?: string;
    shortName?: string;
    longName?: string;
    exchange?: string;
    quoteType?: string;
    currency?: string;
    sector?: string;
    industry?: string;
    regularMarketPrice?: number;
    regularMarketChangePercent?: number;
    [key: string]: any;
}

export interface StockSearchResponse {
    query: string;
    quotes: StockQuote[];
}

export interface TrendingStockResult {
    symbol: string;
    ticker: string;
    shortname?: string;
    longname?: string;
    exchange?: string;
    currency?: string;
    sector?: string;
    industry?: string;
    quoteType?: string;
    regularMarketPrice?: number;
    regularMarketChangePercent?: number;
    isin?: string;
    raw_trending?: any;
}

export interface TrendingStocksResponse {
    region: string;
    count: number;
    results: TrendingStockResult[];
}

export interface CompanyInfo {
    symbol: string;
    longName?: string;
    shortName?: string;
    sector?: string;
    industry?: string;
    marketCap?: number;
    enterpriseValue?: number;
    currentPrice?: number;
    previousClose?: number;
    fiftyTwoWeekRange?: string;
    trailingPE?: number;
    forwardPE?: number;
    profitMargins?: number;
    operatingMargins?: number;
    revenueGrowth?: number;
    earningsGrowth?: number;
    totalRevenue?: number;
    ebitda?: number;
    freeCashflow?: number;
    totalDebt?: number;
    totalCash?: number;
    debtToEquity?: number;
    dividendYield?: number;
    dividendRate?: number;
    recommendationKey?: string;
    recommendationMean?: number;
    targetLowPrice?: number;
    targetMeanPrice?: number;
    targetHighPrice?: number;
    beta?: number;
    fullTimeEmployees?: number;
    longBusinessSummary?: string;
    companyOfficers?: Array<{
        name: string;
        title: string;
    }>;
    [key: string]: any;
}

export interface CompanyInfoResponse {
    symbol: string;
    company_data: CompanyInfo;
}

export interface ScreenerResult {
    symbol: string;
    shortname?: string;
    exchange?: string;
    regularMarketPrice?: number;
    regularMarketChangePercent?: number;
    marketCap?: number;
}

export interface ScreenerResponse {
    screener: string;
    label: string;
    region: string;
    count: number;
    results: ScreenerResult[];
}

export interface AIStockSearchRequest {
    prompt: string;
    existing_stocks?: (string | number | { aktie_id: number })[];
    portfolio_id?: number;
    limit?: number;
}

export interface AIStockCandidate {
    symbol: string;
    ticker: string;
    isin?: string;
    shortName?: string;
    longName?: string;
    sector?: string;
    industry?: string;
    currency?: string;
    exchange?: string;
    regularMarketPrice?: number;
    marketCap?: number;
    info?: any;
}

export interface AIStockSearchResponse {
    prompt: string;
    filters: any;
    excluded: {
        isins: string[];
        symbols: string[];
        aktie_ids: number[];
        note?: string;
    };
    counts: {
        candidates_from_llm: number;
        results_returned: number;
    };
    results: AIStockCandidate[];
    meta: {
        model: string;
        note: string;
    };
}
