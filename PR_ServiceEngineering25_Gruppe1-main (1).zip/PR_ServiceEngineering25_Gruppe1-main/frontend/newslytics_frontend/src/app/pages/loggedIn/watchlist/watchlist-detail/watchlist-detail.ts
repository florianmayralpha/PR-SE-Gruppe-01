import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { WatchlistEntry } from '../../../../models/watchlist';
import { Stock } from '../../../../models/stock';
import { AuthService } from '../../../../services/auth.service';
import { WatchlistService } from '../../../../services/watchlist.service';
import { StockService } from '../../../../services/stock.service';
import { StockSentimentService, StockSentimentResult } from '../../../../services/stock-sentiment.service';
import { SingleStockChatbot } from '../../../../chatbot-windows/single-stock-chatbot/single-stock-chatbot';
import { RemoveWatchlistEntryModalComponent } from '../../../../components/Watchlist/remove-watchlist-entry-modal.component';

interface WatchlistDisplayEntry {
  entry: WatchlistEntry;
  stock: Stock | null;
}

interface SentimentViewModel {
  loading: boolean;
  label: string | null;
  score: number | null;
  error: boolean;
}

@Component({
  standalone: true,
  selector: 'app-watchlist-detail',
  imports: [CommonModule, SingleStockChatbot, RemoveWatchlistEntryModalComponent],
  templateUrl: './watchlist-detail.html',
  styleUrl: './watchlist-detail.scss',
})
export class WatchlistDetail implements OnInit {
  entries: WatchlistEntry[] = [];
  items: WatchlistDisplayEntry[] = [];
  sentiments: Record<number, SentimentViewModel> = {};
  isLoading = false;
  stocksLoading = false;
  error: string | null = null;
  stocksError: string | null = null;
  chatStock: Stock | null = null;
  private removingIds = new Set<number>();
  showRemoveModal = false;
  removeTarget: WatchlistDisplayEntry | null = null;
  removeServerError: string | null = null;

  constructor(
    private authService: AuthService,
    private watchlistService: WatchlistService,
    private stockService: StockService,
    private sentimentService: StockSentimentService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const user = this.authService.currentUser;
    if (!user) {
      this.error = 'Watchlist konnte nicht geladen werden.';
      return;
    }

    this.fetchEntries(user.id);
  }

  private fetchEntries(userId: number): void {
    this.isLoading = true;
    this.watchlistService.getEntriesByUser(userId).subscribe({
      next: (entries) => {
        this.entries = entries;
        this.isLoading = false;
        this.error = null;

        if (entries.length > 0) {
          this.loadStocks(entries);
        } else {
          this.items = [];
          this.stocksError = null;
          this.stocksLoading = false;
        }
      },
      error: () => {
        this.entries = [];
        this.isLoading = false;
        this.error = 'Watchlist konnte nicht geladen werden.';
      },
    });
  }

  private loadStocks(entries: WatchlistEntry[]): void {
    this.stocksLoading = true;
    this.stockService.getStocks().subscribe({
      next: (stocks) => {
        const resolved = entries.map((entry) => ({
          entry,
          stock: stocks.find((stock) => stock.id === entry.aktie_id) || null,
        }));

        this.items = resolved;
        this.sentiments = {};
        this.loadSentimentsForItems(resolved);
        this.stocksLoading = false;
        const unresolved = resolved.filter((item) => !item.stock).length;
        this.stocksError = unresolved === 0 ? null : 'Einige Aktien konnten nicht zugeordnet werden.';
      },
      error: () => {
        this.items = [];
        this.sentiments = {};
        this.stocksLoading = false;
        this.stocksError = 'Aktien konnten nicht geladen werden.';
      },
    });
  }

  private loadSentimentsForItems(items: WatchlistDisplayEntry[]): void {
    items.forEach((item) => {
      if (!item.stock) {
        return;
      }

      const entryId = item.entry.id;
      this.sentiments[entryId] = {
        loading: true,
        label: null,
        score: null,
        error: false,
      };

      this.sentimentService.getSentimentForStock(item.stock).subscribe({
        next: (result: StockSentimentResult) => {
          this.sentiments[entryId] = {
            loading: false,
            label: result.label,
            score: result.score,
            error: false,
          };
        },
        error: () => {
          this.sentiments[entryId] = {
            loading: false,
            label: null,
            score: null,
            error: true,
          };
        },
      });
    });
  }

  goToStocks(): void {
    this.router.navigate(['/stocks']);
  }

  startChat(stock: Stock | null): void {
    if (!stock) {
      this.chatStock = null;
      return;
    }

    this.chatStock = this.chatStock?.id === stock.id ? null : stock;
  }

  clearChat(): void {
    this.chatStock = null;
  }

  requestRemove(item: WatchlistDisplayEntry): void {
    this.removeTarget = item;
    this.removeServerError = null;
    this.showRemoveModal = true;
  }

  closeRemoveModal(): void {
    if (this.removeTarget && this.isRemoving(this.removeTarget.entry.id)) {
      return;
    }

    this.showRemoveModal = false;
    this.removeTarget = null;
    this.removeServerError = null;
  }

  confirmRemove(): void {
    if (!this.removeTarget) {
      return;
    }

    const entry = this.removeTarget.entry;
    if (this.removingIds.has(entry.id)) {
      return;
    }

    this.removeServerError = null;
    this.removingIds.add(entry.id);
    this.watchlistService.deleteEntry(entry.id).subscribe({
      next: () => {
        this.removingIds.delete(entry.id);
        this.entries = this.entries.filter((existing) => existing.id !== entry.id);
        this.items = this.items.filter((item) => item.entry.id !== entry.id);
        delete this.sentiments[entry.id];

        if (this.entries.length === 0) {
          this.stocksError = null;
          this.chatStock = null;
        }

        this.closeRemoveModal();
      },
      error: () => {
        this.removingIds.delete(entry.id);
        this.removeServerError = 'Watchlist-Eintrag konnte nicht entfernt werden.';
      },
    });
  }

  isRemoving(entryId: number): boolean {
    return this.removingIds.has(entryId);
  }

  isActiveChat(stock: Stock | null): boolean {
    if (!stock || !this.chatStock) {
      return false;
    }
    return this.chatStock.id === stock.id;
  }
}
