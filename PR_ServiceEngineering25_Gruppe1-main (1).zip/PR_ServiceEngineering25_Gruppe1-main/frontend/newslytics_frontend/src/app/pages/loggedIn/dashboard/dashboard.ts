import { CommonModule } from '@angular/common';
import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { forkJoin } from 'rxjs';
import { Chart } from 'chart.js/auto';

import { Portfolio } from '../../../models/portfolio';
import { CountryAllocationResponse, SectorAllocationResponse, StockAllocationResponse } from '../../../models/charts';
import { AuthService } from '../../../services/auth.service';
import { PortfolioService } from '../../../services/portfolio.service';
import { PortfolioChartsService } from '../../../services/portfolio-charts.service';
import { PerformanceLinechart } from '../../../components/charts/performance-linechart/performance-linechart';
import { SingleStockPerformanceLinecharts } from '../../../components/charts/single-stock-performance-linecharts/single-stock-performance-linecharts';
import { PortfolioNumbers } from '../../../components/charts/portfolio-numbers/portfolio-numbers';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, PerformanceLinechart, SingleStockPerformanceLinecharts, PortfolioNumbers],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.scss',
})
export class Dashboard implements OnInit, OnDestroy {
  portfolios: Portfolio[] = [];
  selectedPortfolioId: number | null = null;

  sectorAllocation: SectorAllocationResponse | null = null;
  stockAllocation: StockAllocationResponse | null = null;
  countryAllocation: CountryAllocationResponse | null = null;

  private sectorCanvas: ElementRef<HTMLCanvasElement> | null = null;
  private stockCanvas: ElementRef<HTMLCanvasElement> | null = null;
  private countryCanvas: ElementRef<HTMLCanvasElement> | null = null;

  @ViewChild('sectorCanvas')
  set sectorCanvasRef(value: ElementRef<HTMLCanvasElement> | undefined) {
    this.sectorCanvas = value ?? null;
    this.renderChartsSoon();
  }

  @ViewChild('stockCanvas')
  set stockCanvasRef(value: ElementRef<HTMLCanvasElement> | undefined) {
    this.stockCanvas = value ?? null;
    this.renderChartsSoon();
  }

  @ViewChild('countryCanvas')
  set countryCanvasRef(value: ElementRef<HTMLCanvasElement> | undefined) {
    this.countryCanvas = value ?? null;
    this.renderChartsSoon();
  }

  private sectorChart: Chart | null = null;
  private stockChart: Chart | null = null;
  private countryChart: Chart | null = null;
  private renderQueued = false;

  loadingPortfolios = false;
  loadingCharts = false;
  loadError: string | null = null;

  private readonly chartColors = [
    '#3b82f6',
    '#6366f1',
    '#8b5cf6',
    '#14b8a6',
    '#f59e0b',
    '#ef4444',
    '#94a3b8',
  ];

  constructor(
    private authService: AuthService,
    private portfolioService: PortfolioService,
    private portfolioChartsService: PortfolioChartsService
  ) {}

  ngOnInit(): void {
    const user = this.authService.currentUser;
    if (!user) {
      this.loadError = 'Nicht eingeloggt.';
      return;
    }

    this.loadingPortfolios = true;
    this.portfolioService.getPortfoliosByUser(user.id).subscribe({
      next: portfolios => {
        this.portfolios = portfolios;
        this.selectedPortfolioId = portfolios.length ? portfolios[0].id : null;
        this.loadingPortfolios = false;
        this.loadCharts();
      },
      error: err => {
        this.loadingPortfolios = false;
        this.loadError = err?.error?.message ?? 'Portfolios konnten nicht geladen werden.';
      },
    });
  }

  ngOnDestroy(): void {
    this.destroyCharts();
  }

  onPortfolioChange(): void {
    this.loadCharts();
  }

  loadCharts(): void {
    this.loadError = null;
    this.sectorAllocation = null;
    this.stockAllocation = null;
    this.countryAllocation = null;
    this.destroyCharts();

    if (!this.selectedPortfolioId) {
      return;
    }

    this.loadingCharts = true;
    forkJoin({
      sector: this.portfolioChartsService.getSectorAllocation(this.selectedPortfolioId),
      stocks: this.portfolioChartsService.getStockAllocation(this.selectedPortfolioId),
      countries: this.portfolioChartsService.getCountryAllocation(this.selectedPortfolioId),
    }).subscribe({
      next: res => {
        this.sectorAllocation = res.sector;
        this.stockAllocation = res.stocks;
        this.countryAllocation = res.countries;
        this.loadingCharts = false;
        this.renderChartsSoon();
      },
      error: err => {
        this.loadingCharts = false;
        this.loadError = err?.error?.error ?? err?.error?.message ?? 'Charts konnten nicht geladen werden.';
      },
    });
  }

  trackByLabel(_index: number, item: { label: string }): string {
    return item.label;
  }

  getColor(index: number): string {
    return this.chartColors[index % this.chartColors.length];
  }

  private renderChartsSoon(): void {
    if (this.renderQueued) {
      return;
    }
    this.renderQueued = true;
    // Debounce bis nach dem nächsten Microtask/Render-Zyklus
    Promise.resolve().then(() => {
      this.renderQueued = false;
      this.renderCharts();
    });
  }

  private renderCharts(): void {
    this.destroyCharts();
    if (this.loadingCharts) {
      return;
    }

    try {
      if (this.sectorAllocation && this.sectorAllocation.allocation.length && this.sectorCanvas) {
        const values = this.sectorAllocation.allocation.map(a => a.value);
        const sum = values.reduce((acc, v) => acc + (Number.isFinite(v) ? v : 0), 0);
        if (sum > 0) {
          const ctx = this.sectorCanvas.nativeElement.getContext('2d');
          if (ctx) {
            this.sectorChart = new Chart(ctx, {
              type: 'pie',
              data: {
                labels: this.sectorAllocation.allocation.map(a => a.label),
                datasets: [
                  {
                    data: values,
                    backgroundColor: this.sectorAllocation.allocation.map((_a, i) => this.getColor(i)),
                    borderWidth: 0,
                  },
                ],
              },
              options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: { display: false },
                },
              },
            });
          }
        }
      }
    } catch (e) {
      console.error('Sector chart render failed', e);
      this.loadError = 'Piechart (Sektor) konnte nicht gerendert werden.';
    }

    try {
      if (this.stockAllocation && this.stockAllocation.allocation.length && this.stockCanvas) {
        const values = this.stockAllocation.allocation.map(a => a.value);
        const sum = values.reduce((acc, v) => acc + (Number.isFinite(v) ? v : 0), 0);
        if (sum > 0) {
          const ctx = this.stockCanvas.nativeElement.getContext('2d');
          if (ctx) {
            this.stockChart = new Chart(ctx, {
              type: 'pie',
              data: {
                labels: this.stockAllocation.allocation.map(a => a.label),
                datasets: [
                  {
                    data: values,
                    backgroundColor: this.stockAllocation.allocation.map((_a, i) => this.getColor(i)),
                    borderWidth: 0,
                  },
                ],
              },
              options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: { display: false },
                },
              },
            });
          }
        }
      }
    } catch (e) {
      console.error('Stock chart render failed', e);
      this.loadError = 'Piechart (Aktien) konnte nicht gerendert werden.';
    }

    try {
      if (this.countryAllocation && this.countryAllocation.results.length && this.countryCanvas) {
        const labels = this.countryAllocation.results.map(r => r.country);
        const values = this.countryAllocation.results.map(r => r.value);
        const sum = values.reduce((acc, v) => acc + (Number.isFinite(v) ? v : 0), 0);
        if (sum > 0) {
          const ctx = this.countryCanvas.nativeElement.getContext('2d');
          if (ctx) {
            this.countryChart = new Chart(ctx, {
              type: 'bar',
              data: {
                labels,
                datasets: [
                  {
                    label: 'Wert (USD)',
                    data: values,
                    backgroundColor: labels.map((_l, i) => this.getColor(i)),
                  },
                ],
              },
              options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: { display: false },
                },
              scales: {
                x: {
                  ticks: { color: '#475569' },
                  grid: { display: false },
                },
                y: {
                  ticks: { color: '#475569' },
                  grid: { color: 'rgba(148, 163, 184, 0.25)' },
                },
              },
              },
            });
          }
        }
      }
    } catch (e) {
      console.error('Country chart render failed', e);
      this.loadError = 'Balkendiagramm (Länder) konnte nicht gerendert werden.';
    }
  }

  private destroyCharts(): void {
    if (this.sectorChart) {
      this.sectorChart.destroy();
      this.sectorChart = null;
    }
    if (this.stockChart) {
      this.stockChart.destroy();
      this.stockChart = null;
    }
    if (this.countryChart) {
      this.countryChart.destroy();
      this.countryChart = null;
    }
  }
}
