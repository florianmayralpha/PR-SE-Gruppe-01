import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { StockDiscovery } from '../../../components/stock/stock-discovery/stock-discovery';
import { CategoryStockSearchChatbot } from '../../../chatbot-windows/category-stock-search-chatbot/category-stock-search-chatbot';
import { AuthService } from '../../../services/auth.service';
import { PortfolioService } from '../../../services/portfolio.service';
import { Portfolio } from '../../../models/portfolio';

@Component({
  selector: 'app-discovery',
  standalone: true,
  imports: [CommonModule, FormsModule, StockDiscovery, CategoryStockSearchChatbot],
  templateUrl: './discovery.html',
  styleUrl: './discovery.scss',
})
export class Discovery implements OnInit {
  leftScreeners = [
    { type: 'day_gainers', region: 'US' },
    { type: 'day_losers', region: 'US' },
    { type: 'esg_leaders', region: 'US' },
    { type: 'growth_technology_stocks', region: 'US' },
    
  ];

  rightScreeners = [
    { type: 'most_actives', region: 'US' },
    { type: 'undervalued_growth_stocks', region: 'US' },
    { type: 'green_energy_stocks', region: 'US' },
    { type: 'artificial_intelligence', region: 'US' }
  ];

  portfolios: Portfolio[] = [];
  selectedPortfolioId: number | null = null;
  isLoggedIn = false;
  loadingPortfolios = false;

  constructor(
    public authService: AuthService,
    private portfolioService: PortfolioService
  ) {}

  ngOnInit(): void {
    this.isLoggedIn = this.authService.isAuthenticated;
    
    if (this.isLoggedIn) {
      this.loadPortfolios();
    }
  }

  private loadPortfolios(): void {
    this.loadingPortfolios = true;
    this.portfolioService.getPortfoliosSilently().subscribe({
      next: (portfolios) => {
        this.portfolios = portfolios;
        this.loadingPortfolios = false;
      },
      error: (err) => {
        const status = (err && typeof err === 'object' && 'status' in err) ? (err as any).status : undefined;
        if (status === 401 || status === 403 || status === 422) {
          this.isLoggedIn = false;
          this.selectedPortfolioId = null;
          this.portfolios = [];
        } else {
          console.error('Failed to load portfolios:', err);
        }
        this.loadingPortfolios = false;
      }
    });
  }

  onPortfolioChange(): void {
  }
}
