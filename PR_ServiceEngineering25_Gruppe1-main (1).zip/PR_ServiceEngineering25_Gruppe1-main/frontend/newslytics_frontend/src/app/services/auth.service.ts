import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject, tap } from 'rxjs';
import { User, LoginRequest, AuthResponse, RegisterRequest } from '../models/auth';
import { environment } from '../config';

@Injectable({
    providedIn: 'root'
})
export class AuthService {
    private readonly baseUrl = environment.apiBaseUrl;

    private _currentUser: User | null = null;
    private _token: string | null = null;

    private authRequiredSubject = new Subject<void>();
    authRequired$: Observable<void> = this.authRequiredSubject.asObservable();

    get currentUser(): User | null {
        return this._currentUser;
    }

    get token(): string | null {
        if (!this._token) {
            return null;
        }

        if (this.isJwtExpired(this._token)) {
            this.logout();
            return null;
        }

        return this._token;
    }

    constructor(private http: HttpClient) {
        this.restoreFromStorage();
    }

    login(payload: LoginRequest): Observable<AuthResponse> {
        return this.http
            .post<AuthResponse>(`${this.baseUrl}/auth/login`, payload)
            .pipe(tap(res => this.handleAuthSuccess(res)));
    }

    logout(): void {
        this._currentUser = null;
        this._token = null;
        localStorage.removeItem('auth_token');
        localStorage.removeItem('auth_user');
    }

    register(payload: RegisterRequest): Observable<User> {
        return this.http.post<User>(`${this.baseUrl}/auth/register`, payload);
    }

    get isAuthenticated(): boolean {
        return !!this._currentUser && !!this.token;
    }

    notifyAuthRequired(): void {
        this.authRequiredSubject.next();
    }

    private handleAuthSuccess(res: AuthResponse): void {
        this._token = res.access_token;
        this._currentUser = res.user;

        localStorage.setItem('auth_token', res.access_token);
        localStorage.setItem('auth_user', JSON.stringify(res.user));
    }

    private restoreFromStorage(): void {
        const token = localStorage.getItem('auth_token');
        const userStr = localStorage.getItem('auth_user');

        if (token && userStr) {
            try {
                this._token = token;
                this._currentUser = JSON.parse(userStr) as User;
            } catch {
                this.logout();
            }
        }
    }

    private isJwtExpired(token: string): boolean {
        try {
            const payloadPart = token.split('.')[1];
            if (!payloadPart) {
                return true;
            }

            // base64url -> base64
            const base64 = payloadPart.replace(/-/g, '+').replace(/_/g, '/');
            const jsonPayload = decodeURIComponent(
                atob(base64)
                    .split('')
                    .map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
                    .join('')
            );
            const payload = JSON.parse(jsonPayload) as { exp?: number };

            if (!payload.exp) {
                return true;
            }

            const nowSeconds = Math.floor(Date.now() / 1000);
            return payload.exp <= nowSeconds;
        } catch {
            return true;
        }
    }
}