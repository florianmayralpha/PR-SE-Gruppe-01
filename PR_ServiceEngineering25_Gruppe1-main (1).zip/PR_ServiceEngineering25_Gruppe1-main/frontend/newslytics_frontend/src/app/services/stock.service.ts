import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';

import { environment } from '../config';
import { 
    Stock, 
    Transaction, 
    StockSearchResponse, 
    TrendingStocksResponse,
    CompanyInfoResponse,
    ScreenerResponse,
    AIStockSearchRequest,
    AIStockSearchResponse
} from '../models/stock';

interface CachedTrendingStocks {
    data: TrendingStocksResponse;
    timestamp: number;
}

@Injectable({
    providedIn: 'root'
})
export class StockService {
    private readonly baseUrl = environment.apiBaseUrl;
    private readonly CACHE_TTL = 5 * 60 * 1000; // 5 minutes in milliseconds
    private trendingStocksCache = new Map<string, CachedTrendingStocks>();

    constructor(private http: HttpClient) {}

    getStocks(): Observable<Stock[]> {
        return this.http.get<Stock[]>(`${this.baseUrl}/aktien`);
    }

    getStock(id: number): Observable<Stock> {
        return this.http.get<Stock>(`${this.baseUrl}/aktien/${id}`);
    }

    getTransactions(): Observable<Transaction[]> {
        return this.http.get<Transaction[]>(`${this.baseUrl}/transaktionen`);
    }

    getTransactionsByPortfolio(portfolioId: number): Observable<Transaction[]> {
        return this.http.get<Transaction[]>(`${this.baseUrl}/portfolios/${portfolioId}/transaktionen`);
    }

    searchStocks(query: string): Observable<StockSearchResponse> {
        const params = new HttpParams().set('name', query);
        return this.http.get<StockSearchResponse>(`${this.baseUrl}/aktie/search`, { params });
    }

    getTrendingStocks(region: string = 'US'): Observable<TrendingStocksResponse> {
        // Check if we have cached data for this region
        const cached = this.trendingStocksCache.get(region);
        const now = Date.now();

        // Return cached data if it exists and is still valid
        if (cached && (now - cached.timestamp) < this.CACHE_TTL) {
            console.log(`Returning cached trending stocks for region: ${region}`);
            return of(cached.data);
        }

        // Fetch fresh data from API
        console.log(`Fetching fresh trending stocks for region: ${region}`);
        const params = new HttpParams().set('region', region);
        return this.http.get<TrendingStocksResponse>(`${this.baseUrl}/aktie/trending`, { params }).pipe(
            tap(data => {
                // Cache the response
                this.trendingStocksCache.set(region, {
                    data,
                    timestamp: now
                });
            })
        );
    }

    createStock(stock: Partial<Stock>): Observable<Stock> {
        return this.http.post<Stock>(`${this.baseUrl}/aktien`, stock);
    }

    getCompanyInfo(symbol: string): Observable<CompanyInfoResponse> {
        const params = new HttpParams().set('symbol', symbol);
        return this.http.get<CompanyInfoResponse>(`${this.baseUrl}/companyinfo`, { params });
    }

    getScreenerStocks(screenerType: string, region: string = 'US', count: number = 25): Observable<ScreenerResponse> {
        const params = new HttpParams()
            .set('type', screenerType)
            .set('region', region)
            .set('count', count.toString());
        return this.http.get<ScreenerResponse>(`${this.baseUrl}/screener`, { params });
    }

    searchStocksWithAI(request: AIStockSearchRequest): Observable<AIStockSearchResponse> {
        return this.http.post<AIStockSearchResponse>(`${this.baseUrl}/ai/stock-search`, request);
    }
}
