import { HttpContextToken } from '@angular/common/http';

export const SKIP_AUTH_REQUIRED = new HttpContextToken<boolean>(() => false);
