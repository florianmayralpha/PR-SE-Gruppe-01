import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from '../config';
import {
	AggregatedPortfolioPerformanceResponse,
	CountryAllocationResponse,
	MarketDataResponse,
	PerformanceLinechartResponse,
	SectorAllocationResponse,
	StockAllocationResponse,
} from '../models/charts';

@Injectable({
	providedIn: 'root'
})
export class PortfolioChartsService {
	private readonly baseUrl = environment.apiBaseUrl;

	constructor(private http: HttpClient) {}

	getSectorAllocation(portfolioId: number): Observable<SectorAllocationResponse> {
		return this.http.get<SectorAllocationResponse>(`${this.baseUrl}/portfolios/${portfolioId}/sector`);
	}

	getStockAllocation(portfolioId: number): Observable<StockAllocationResponse> {
		return this.http.get<StockAllocationResponse>(
			`${this.baseUrl}/portfolios/${portfolioId}/stock-allocation`
		);
	}

	getCountryAllocation(portfolioId: number): Observable<CountryAllocationResponse> {
		return this.http.get<CountryAllocationResponse>(
			`${this.baseUrl}/portfolios/${portfolioId}/country-allocation`
		);
	}

	getPerformanceLinechart(
		portfolioId: number,
		options?: {
			range?: string;
			start?: string;
			end?: string;
			include_stocks?: boolean;
			include_transactions?: boolean;
			include_positions_snapshot?: boolean;
		}
	): Observable<PerformanceLinechartResponse> {
		let params = new HttpParams();

		if (options?.range) {
			params = params.set('range', options.range);
		}
		if (options?.start) {
			params = params.set('start', options.start);
		}
		if (options?.end) {
			params = params.set('end', options.end);
		}
		if (options?.include_stocks !== undefined) {
			params = params.set('include_stocks', options.include_stocks ? '1' : '0');
		}
		if (options?.include_transactions !== undefined) {
			params = params.set('include_transactions', options.include_transactions ? '1' : '0');
		}
		if (options?.include_positions_snapshot !== undefined) {
			params = params.set('include_positions_snapshot', options.include_positions_snapshot ? '1' : '0');
		}

		return this.http.get<PerformanceLinechartResponse>(
			`${this.baseUrl}/portfolios/${portfolioId}/performance-linechart`,
			{ params }
		);
	}

	getMarketData(
		symbol: string,
		options?: {
			range?: string;
			interval?: string;
		}
	): Observable<MarketDataResponse> {
		let params = new HttpParams().set('symbol', symbol);

		if (options?.range) {
			params = params.set('range', options.range);
		}
		if (options?.interval) {
			params = params.set('interval', options.interval);
		}

		return this.http.get<MarketDataResponse>(`${this.baseUrl}/marketdata`, { params });
	}

	getAggregatedPortfolioPerformance(
		userId: number,
		options?: {
			include_portfolios?: boolean;
			include_positions?: boolean;
		}
	): Observable<AggregatedPortfolioPerformanceResponse> {
		let params = new HttpParams();

		if (options?.include_portfolios !== undefined) {
			params = params.set('include_portfolios', options.include_portfolios ? '1' : '0');
		}
		if (options?.include_positions !== undefined) {
			params = params.set('include_positions', options.include_positions ? '1' : '0');
		}

		return this.http.get<AggregatedPortfolioPerformanceResponse>(
			`${this.baseUrl}/users/${userId}/portfolios/performance`,
			{ params }
		);
	}
}
