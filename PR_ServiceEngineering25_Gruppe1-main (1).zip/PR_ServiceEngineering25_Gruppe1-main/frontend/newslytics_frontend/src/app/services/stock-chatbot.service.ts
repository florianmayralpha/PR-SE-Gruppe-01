import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map } from 'rxjs/operators';

import { environment } from '../config';
import { Stock, StockQuote, TrendingStockResult } from '../models/stock';

const STOCK_CHATBOT_INSTRUCTIONS = '1. Versuche immer eine Antwort zu geben ' +
  '2. Verwende immer die mitgegebene Aktie als Grundlage' +
  '3. Antworte immer kurz und prägnant - Gib kein "Antwort:" aus' + 
  '4. Antworte auf Deutsch und formatiere in Markdown.' +
  '5. Wenn du zuwenige Informationen hast, dann abstrahiere die Frage und versuche sie trotzdem zu beantworten.';

export type ChatbotSender = 'user' | 'assistant';

export interface StockChatMessage {
  sender: ChatbotSender;
  text: string;
}

export interface StockChatRequest {
  stock: StockContextPayload;
  message: string;
  history: StockChatMessage[];
}

export interface StockChatResponse {
  reply: string;
  timestamp: string;
}

interface AiAskResponse {
  ticker: string;
  used_articles: number;
  answer: string;
}

export interface StockContextPayload {
  symbol?: string;
  ticker?: string;
  isin?: string;
  name?: string;
  shortName?: string;
  longName?: string;
  currency?: string;
  exchange?: string;
}

@Injectable({ providedIn: 'root' })
export class StockChatbotService {
  private readonly baseUrl = environment.apiBaseUrl;

  constructor(private http: HttpClient) {}

  sendMessage(payload: StockChatRequest): Observable<StockChatResponse> {
    const ticker = this.resolveTicker(payload.stock);
    if (!ticker) {
      return throwError(() => new Error('No ticker/symbol available for this stock.'));
    }

    const prompt = this.buildPrompt(payload, ticker);

    return this.http
      .post<AiAskResponse>(`${this.baseUrl}/ai/ask`, {
        ticker,
        prompt,
      })
      .pipe(
        map((response) => ({
          reply: response.answer,
          timestamp: new Date().toISOString(),
        }))
      );
  }

  buildStockContext(stock: Stock | StockQuote | TrendingStockResult): StockContextPayload {
    const payload: StockContextPayload = {};

    if ('symbol' in stock && stock.symbol) {
      payload.symbol = stock.symbol;
    }

    if ('ticker' in stock && stock.ticker) {
      payload.ticker = stock.ticker;
    }

    if (stock.isin) {
      payload.isin = stock.isin;
    }

    if ('name' in stock && stock.name) {
      payload.name = stock.name;
    }

    if ('shortName' in stock && stock.shortName) {
      payload.shortName = stock.shortName;
    }

    if (!payload.shortName && 'shortname' in stock && stock.shortname) {
      payload.shortName = stock.shortname;
    }

    if ('longName' in stock && stock.longName) {
      payload.longName = stock.longName;
    }

    if (!payload.longName && 'longname' in stock && stock.longname) {
      payload.longName = stock.longname;
    }

    if (stock.currency) {
      payload.currency = stock.currency;
    }

    if ('exchange' in stock && stock.exchange) {
      payload.exchange = stock.exchange;
    }

    return payload;
  }

  private resolveTicker(stock: StockContextPayload): string | null {
    const candidate = (stock.symbol || stock.ticker || '').trim();
    if (candidate) {
      return candidate.toUpperCase();
    }

    if (stock.isin) {
      const isinCandidate = stock.isin.trim();
      return isinCandidate ? isinCandidate.toUpperCase() : null;
    }

    return null;
  }

  private buildPrompt(request: StockChatRequest, ticker: string): string {
    const displayName =
      request.stock.name ||
      request.stock.shortName ||
      request.stock.longName ||
      ticker;

    const recentHistory = (request.history || []).slice(-10);
    const historyText = recentHistory
      .map((msg) => `${msg.sender === 'user' ? 'User' : 'Assistant'}: ${msg.text}`)
      .join('\n');

    const header = `Aktie: ${displayName} (${ticker})\nAnweisungen: ${STOCK_CHATBOT_INSTRUCTIONS}`;
    const historyBlock = historyText ? `\n\nBisheriger Verlauf:\n${historyText}` : '';

    return `${header}${historyBlock}\n\nUser-Frage:\n${request.message}`;
  }
}
