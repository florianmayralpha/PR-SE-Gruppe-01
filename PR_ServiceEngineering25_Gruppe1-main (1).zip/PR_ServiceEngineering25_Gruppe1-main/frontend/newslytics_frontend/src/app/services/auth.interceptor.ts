import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';

import { AuthService } from './auth.service';
import { SKIP_AUTH_REQUIRED } from './http-context.tokens';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
    const authService = inject(AuthService);
    const router = inject(Router);
    const token = authService.token;
    const isAuthEndpoint = req.url.includes('/auth/');
    const skipAuthRequired = req.context.get(SKIP_AUTH_REQUIRED);
    
    const publicEndpoints = [
        '/aktie/search',
        '/aktie/trending',
        '/aktien',
        '/companyinfo',
        '/screener'
    ];
    const isPublicEndpoint = publicEndpoints.some(endpoint => req.url.includes(endpoint));

    if (!token) {
        if (!skipAuthRequired && !isAuthEndpoint && !isPublicEndpoint) {
            authService.notifyAuthRequired();
        }
        return next(req);
    }

    const authReq = req.clone({
        setHeaders: {
            Authorization: `Bearer ${token}`
        }
    });

    return next(authReq).pipe(
        catchError((err: unknown) => {
            if (err instanceof HttpErrorResponse && (err.status === 401 || err.status === 422)) {
                authService.logout();

                if (!skipAuthRequired) {
                    authService.notifyAuthRequired();
                    router.navigate(['/home']);
                }
            }
            return throwError(() => err);
        })
    );
};
