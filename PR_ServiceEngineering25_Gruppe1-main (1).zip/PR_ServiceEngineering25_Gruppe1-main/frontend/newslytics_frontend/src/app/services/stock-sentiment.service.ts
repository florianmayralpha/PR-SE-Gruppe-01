import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';

import { environment } from '../config';
import { Stock, StockQuote, TrendingStockResult } from '../models/stock';

interface AiSentimentResponse {
  ticker: string;
  used_articles: number;
  sentiment: {
    score: number;
    label: string;
    begruendung: string;
  };
}

export interface StockSentimentResult {
  ticker: string;
  usedArticles: number;
  score: number | null;
  label: string;
  justification: string;
}

@Injectable({ providedIn: 'root' })
export class StockSentimentService {
  private readonly baseUrl = environment.apiBaseUrl;
  private readonly cache = new Map<string, Observable<StockSentimentResult>>();

  constructor(private http: HttpClient) {}

  getSentimentForStock(stock: Stock | StockQuote | TrendingStockResult): Observable<StockSentimentResult> {
    const ticker = this.resolveTicker(stock);
    if (!ticker) {
      return throwError(() => new Error('No ticker/symbol available for this stock.'));
    }

    const cached = this.cache.get(ticker);
    if (cached) {
      return cached;
    }

    const request$ = this.http
      .post<AiSentimentResponse>(`${this.baseUrl}/ai/sentiment`, {
        ticker,
      })
      .pipe(
        map((response) => {
          const sentiment = response.sentiment || ({} as AiSentimentResponse['sentiment']);
          const score = typeof sentiment.score === 'number' ? sentiment.score : null;

          return {
            ticker: response.ticker,
            usedArticles: response.used_articles,
            score,
            label: sentiment.label || 'unbekannt',
            justification: sentiment.begruendung || '',
          };
        }),
        shareReplay(1)
      );

    this.cache.set(ticker, request$);
    return request$;
  }

  clearCache(): void {
    this.cache.clear();
  }

  private resolveTicker(stock: Stock | StockQuote | TrendingStockResult): string | null {
    const symbolCandidate = 'symbol' in stock ? (stock.symbol || '') : '';
    const tickerCandidate = 'ticker' in stock ? (stock.ticker || '') : '';
    const candidate = (symbolCandidate || tickerCandidate).trim();
    if (candidate) {
      return candidate.toUpperCase();
    }

    const isinCandidate = (stock.isin || '').trim();
    if (isinCandidate) {
      return isinCandidate.toUpperCase();
    }

    const nameCandidate = ('name' in stock ? (stock.name || '') : '').trim();
    return nameCandidate ? nameCandidate : null;
  }
}
