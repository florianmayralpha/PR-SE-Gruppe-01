import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map } from 'rxjs/operators';

import { environment } from '../config';

const PORTFOLIO_CHATBOT_INSTRUCTIONS =
  '1. Antworte immer auf Deutsch und formatiere in Markdown. ' +
  '2. Nutze den bereitgestellten Portfolio-Kontext (Positionen) als Grundlage. ' +
  '3. Wenn Informationen fehlen, sage das klar und nenne Annahmen. ' +
  '4. Gib keine Anlageberatung im Sinne einer Garantie.';

export type ChatbotSender = 'user' | 'assistant';

export interface PortfolioChatMessage {
  sender: ChatbotSender;
  text: string;
}

export interface PortfolioChatRequest {
  portfolioId: number;
  message: string;
  history: PortfolioChatMessage[];
}

export interface PortfolioChatResponse {
  reply: string;
  timestamp: string;
  positionsCount: number;
}

interface PortfolioAiAskResponse {
  portfolio_id: number;
  positions_count: number;
  answer: string;
}

@Injectable({ providedIn: 'root' })
export class PortfolioChatbotService {
  private readonly baseUrl = environment.apiBaseUrl;

  constructor(private http: HttpClient) {}

  sendMessage(payload: PortfolioChatRequest): Observable<PortfolioChatResponse> {
    if (!payload.portfolioId || payload.portfolioId <= 0) {
      return throwError(() => new Error('Invalid portfolio id.'));
    }

    const prompt = this.buildPrompt(payload);

    return this.http
      .post<PortfolioAiAskResponse>(`${this.baseUrl}/ai/portfolio/ask`, {
        portfolio_id: payload.portfolioId,
        prompt,
      })
      .pipe(
        map((response) => ({
          reply: response.answer,
          positionsCount: response.positions_count,
          timestamp: new Date().toISOString(),
        }))
      );
  }

  private buildPrompt(request: PortfolioChatRequest): string {
    const recentHistory = (request.history || []).slice(-10);
    const historyText = recentHistory
      .map((msg) => `${msg.sender === 'user' ? 'User' : 'Assistant'}: ${msg.text}`)
      .join('\n');

    const header = `Portfolio-ID: ${request.portfolioId}\nAnweisungen: ${PORTFOLIO_CHATBOT_INSTRUCTIONS}`;
    const historyBlock = historyText ? `\n\nBisheriger Verlauf:\n${historyText}` : '';

    return `${header}${historyBlock}\n\nUser-Frage:\n${request.message}`;
  }
}
