import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  standalone: true,
  selector: 'app-remove-watchlist-entry-modal',
  imports: [CommonModule],
  templateUrl: './remove-watchlist-entry-modal.component.html',
  styleUrl: './remove-watchlist-entry-modal.component.scss',
})
export class RemoveWatchlistEntryModalComponent {
  @Input() stockName: string | null = null;
  @Input() stockIsin: string | null = null;
  @Input() removing = false;
  @Input() error: string | null = null;

  @Output() close = new EventEmitter<void>();
  @Output() confirm = new EventEmitter<void>();

  onOverlayClick(event: MouseEvent): void {
    if (this.removing) {
      return;
    }

    if ((event.target as HTMLElement).classList.contains('modal-overlay')) {
      this.close.emit();
    }
  }
}
