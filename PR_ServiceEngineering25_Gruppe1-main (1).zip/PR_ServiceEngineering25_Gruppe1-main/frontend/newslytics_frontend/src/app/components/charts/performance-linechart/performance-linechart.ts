import { CommonModule } from '@angular/common';
import { Component, ElementRef, Input, OnChanges, OnDestroy, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Chart } from 'chart.js/auto';

import { PerformanceLinechartResponse } from '../../../models/charts';
import { PortfolioChartsService } from '../../../services/portfolio-charts.service';

@Component({
	selector: 'app-performance-linechart',
	standalone: true,
	imports: [CommonModule, FormsModule],
	templateUrl: './performance-linechart.html',
	styleUrl: './performance-linechart.scss',
})
export class PerformanceLinechart implements OnInit, OnChanges, OnDestroy {
	@Input() portfolioId: number | null = null;

	@ViewChild('performanceCanvas')
	set performanceCanvasRef(value: ElementRef<HTMLCanvasElement> | undefined) {
		this.performanceCanvas = value ?? null;
		this.renderChartSoon();
	}

	private performanceCanvas: ElementRef<HTMLCanvasElement> | null = null;
	private performanceChart: Chart | null = null;
	private renderQueued = false;

	performanceData: PerformanceLinechartResponse | null = null;
	loading = false;
	error: string | null = null;

	// Range selection
	selectedRange: string = '1mo';
	rangeOptions = [
		{ value: '1mo', label: '1 Monat' },
		{ value: '3mo', label: '3 Monate' },
		{ value: '6mo', label: '6 Monate' },
		{ value: '1y', label: '1 Jahr' },
		{ value: 'ytd', label: 'YTD' },
		{ value: 'max', label: 'Max' },
		{ value: 'custom', label: 'Benutzerdefiniert' },
	];

	// Custom date range
	customStart: string = '';
	customEnd: string = '';
	useCustomRange = false;

	private readonly chartColors = [
		'#3b82f6', // blue
		'#10b981', // green
		'#f59e0b', // amber
		'#ef4444', // red
		'#8b5cf6', // violet
		'#14b8a6', // teal
	];

	constructor(private portfolioChartsService: PortfolioChartsService) {}

	ngOnInit(): void {
		this.loadPerformanceData();
	}

	ngOnChanges(changes: SimpleChanges): void {
		if (changes['portfolioId'] && !changes['portfolioId'].firstChange) {
			this.loadPerformanceData();
		}
	}

	ngOnDestroy(): void {
		this.destroyChart();
	}

	onRangeChange(): void {
		this.useCustomRange = this.selectedRange === 'custom';
		if (!this.useCustomRange) {
			this.customStart = '';
			this.customEnd = '';
			this.loadPerformanceData();
		}
	}

	onCustomDateChange(): void {
		if (this.useCustomRange && this.customStart && this.customEnd) {
			this.loadPerformanceData();
		}
	}

	loadPerformanceData(): void {
		if (!this.portfolioId) {
			this.performanceData = null;
			this.destroyChart();
			return;
		}

		this.loading = true;
		this.error = null;

		const options: any = {
			include_stocks: false,
			include_transactions: false,
			include_positions_snapshot: false,
		};

		if (this.useCustomRange && this.customStart && this.customEnd) {
			options.start = this.customStart;
			options.end = this.customEnd;
		} else if (this.selectedRange !== 'custom') {
			options.range = this.selectedRange;
		}

		this.portfolioChartsService.getPerformanceLinechart(this.portfolioId, options).subscribe({
			next: data => {
				this.performanceData = data;
				this.loading = false;
				this.renderChartSoon();
			},
			error: err => {
				this.loading = false;
				this.error = err?.error?.error ?? err?.error?.message ?? 'Performance-Daten konnten nicht geladen werden.';
				this.performanceData = null;
			},
		});
	}

	private renderChartSoon(): void {
		if (this.renderQueued) {
			return;
		}
		this.renderQueued = true;
		Promise.resolve().then(() => {
			this.renderQueued = false;
			this.renderChart();
		});
	}

	private renderChart(): void {
		this.destroyChart();

		if (this.loading || !this.performanceData || !this.performanceCanvas) {
			return;
		}

		const ctx = this.performanceCanvas.nativeElement.getContext('2d');
		if (!ctx) {
			return;
		}

		try {
			let labels: string[] = [];
			let datasets: any[] = [];

			// Show total portfolio performance
			if (this.performanceData.series && this.performanceData.series.length > 0) {
				labels = this.performanceData.series.map(point => point.date);
				datasets = [
					{
						label: this.performanceData.portfolio_name || 'Portfolio Gesamt',
						data: this.performanceData.series.map(point => point.total_value),
						borderColor: this.chartColors[0],
						backgroundColor: this.chartColors[0] + '20',
						borderWidth: 2,
						fill: true,
						tension: 0.4,
					},
				];
			}

			if (labels.length === 0 || datasets.length === 0) {
				return;
			}

			this.performanceChart = new Chart(ctx, {
				type: 'line',
				data: {
					labels,
					datasets,
				},
				options: {
					responsive: true,
					maintainAspectRatio: false,
					plugins: {
						legend: {
							display: true,
							position: 'top',
							labels: {
								color: '#cbd5e1',
								font: {
									size: 12,
								},
							},
						},
						tooltip: {
							mode: 'index',
							intersect: false,
							callbacks: {
								label: context => {
									const label = context.dataset.label || '';
									const value = (context.parsed.y ?? 0).toFixed(2);
								return `${label}: $${value}`;
								},
							},
						},
					},
					scales: {
						x: {
							ticks: {
								color: '#475569',
								maxRotation: 45,
								minRotation: 0,
							},
							grid: {
								display: false,
							},
						},
						y: {
							ticks: {
								color: '#475569',
								callback: value => `$${value}`,
							},
							grid: {
								color: 'rgba(148, 163, 184, 0.25)',
							},
						},
					},
					interaction: {
						mode: 'nearest',
						axis: 'x',
						intersect: false,
					},
				},
			});
		} catch (e) {
			console.error('Performance chart render failed', e);
			this.error = 'Linechart konnte nicht gerendert werden.';
		}
	}

	private destroyChart(): void {
		if (this.performanceChart) {
			this.performanceChart.destroy();
			this.performanceChart = null;
		}
	}
}
