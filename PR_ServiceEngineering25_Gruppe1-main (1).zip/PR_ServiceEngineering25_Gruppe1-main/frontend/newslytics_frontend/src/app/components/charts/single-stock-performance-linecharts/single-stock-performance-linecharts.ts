import { CommonModule } from '@angular/common';
import { Component, ElementRef, Input, OnChanges, OnDestroy, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Chart } from 'chart.js/auto';

import { MarketDataResponse, StockAllocationResponse } from '../../../models/charts';
import { PortfolioChartsService } from '../../../services/portfolio-charts.service';

@Component({
	selector: 'app-single-stock-performance-linecharts',
	standalone: true,
	imports: [CommonModule, FormsModule],
	templateUrl: './single-stock-performance-linecharts.html',
	styleUrl: './single-stock-performance-linecharts.scss',
})
export class SingleStockPerformanceLinecharts implements OnInit, OnChanges, OnDestroy {
	@Input() portfolioId: number | null = null;

	@ViewChild('stockPerformanceCanvas')
	set stockPerformanceCanvasRef(value: ElementRef<HTMLCanvasElement> | undefined) {
		this.stockPerformanceCanvas = value ?? null;
		this.renderChartSoon();
	}

	private stockPerformanceCanvas: ElementRef<HTMLCanvasElement> | null = null;
	private stockPerformanceChart: Chart | null = null;
	private renderQueued = false;

	marketData: MarketDataResponse | null = null;
	loadingStocks = false;
	loadingMarketData = false;
	error: string | null = null;

	// Available stocks from the portfolio
	availableStocks: { isin: string; name: string; symbol: string | null }[] = [];
	selectedStockSymbol: string | null = null;

	// Range selection - Yahoo Finance free tier supported values
	selectedRange: string = '1mo';
	rangeOptions = [
		{ value: '1d', label: '1 Tag' },
		{ value: '5d', label: '5 Tage' },
		{ value: '1mo', label: '1 Monat' },
		{ value: '3mo', label: '3 Monate' },
		{ value: '6mo', label: '6 Monate' },
		{ value: '1y', label: '1 Jahr' },
		{ value: '2y', label: '2 Jahre' },
		{ value: '5y', label: '5 Jahre' },
		{ value: 'ytd', label: 'YTD' },
		{ value: 'max', label: 'Max' },
	];

	// Interval selection
	selectedInterval: string = '1d';
	intervalOptions = [
		{ value: '1d', label: '1 Tag' },
		{ value: '1wk', label: '1 Woche' },
		{ value: '1mo', label: '1 Monat' },
	];

	private readonly chartColors = [
		'#3b82f6', // blue
		'#10b981', // green
		'#f59e0b', // amber
		'#ef4444', // red
		'#8b5cf6', // violet
		'#14b8a6', // teal
	];

	constructor(private portfolioChartsService: PortfolioChartsService) {}

	ngOnInit(): void {
		this.loadAvailableStocks();
	}

	ngOnChanges(changes: SimpleChanges): void {
		if (changes['portfolioId'] && !changes['portfolioId'].firstChange) {
			this.selectedStockSymbol = null;
			this.loadAvailableStocks();
		}
	}

	ngOnDestroy(): void {
		this.destroyChart();
	}

	onRangeChange(): void {
		if (this.selectedStockSymbol) {
			this.loadMarketData();
		}
	}

	onIntervalChange(): void {
		if (this.selectedStockSymbol) {
			this.loadMarketData();
		}
	}

	onStockChange(): void {
		if (this.selectedStockSymbol) {
			this.loadMarketData();
		} else {
			this.marketData = null;
			this.destroyChart();
		}
	}

	loadAvailableStocks(): void {
		if (!this.portfolioId) {
			this.availableStocks = [];
			this.marketData = null;
			this.destroyChart();
			return;
		}

		this.loadingStocks = true;
		this.error = null;

		this.portfolioChartsService.getStockAllocation(this.portfolioId).subscribe({
			next: data => {
				this.availableStocks = data.allocation.map(stock => {
					// Extract symbol from ISIN if available, otherwise use ISIN
					// Yahoo Finance typically uses symbols like "AAPL", "MSFT", "BMW.DE"
					// For German stocks, we might need to append .DE, .F, etc.
					let symbol: string | null = null;
					
					// Try to derive symbol from ISIN (simplified approach)
					// In a real app, you'd have a proper mapping
					if (stock.isin) {
						// For demo, we'll just use the ISIN and let the backend handle it
						// The backend should ideally return the symbol
						symbol = stock.isin;
					}

					return {
						isin: stock.isin,
						name: stock.label,
						symbol: symbol,
					};
				});

				this.loadingStocks = false;

				// Auto-select first stock if none selected
				if (!this.selectedStockSymbol && this.availableStocks.length > 0 && this.availableStocks[0].symbol) {
					this.selectedStockSymbol = this.availableStocks[0].symbol;
					this.loadMarketData();
				}
			},
			error: err => {
				this.loadingStocks = false;
				this.error = err?.error?.error ?? err?.error?.message ?? 'Aktien konnten nicht geladen werden.';
				this.availableStocks = [];
			},
		});
	}

	loadMarketData(): void {
		if (!this.selectedStockSymbol) {
			return;
		}

		this.loadingMarketData = true;
		this.error = null;

		this.portfolioChartsService
			.getMarketData(this.selectedStockSymbol, {
				range: this.selectedRange,
				interval: this.selectedInterval,
			})
			.subscribe({
				next: data => {
					this.marketData = data;
					this.loadingMarketData = false;
					this.renderChartSoon();
				},
				error: err => {
					this.loadingMarketData = false;
					this.error = err?.error?.description ?? err?.error?.error ?? 'Market-Daten konnten nicht geladen werden.';
					this.marketData = null;
				},
			});
	}

	private renderChartSoon(): void {
		if (this.renderQueued) {
			return;
		}
		this.renderQueued = true;
		Promise.resolve().then(() => {
			this.renderQueued = false;
			this.renderChart();
		});
	}

	private renderChart(): void {
		this.destroyChart();

		if (this.loadingMarketData || !this.marketData || !this.stockPerformanceCanvas) {
			return;
		}

		const ctx = this.stockPerformanceCanvas.nativeElement.getContext('2d');
		if (!ctx) {
			return;
		}

		try {
			const labels = this.marketData.data.map(point => point.datetime.split('T')[0]);
			const closeData = this.marketData.data.map(point => point.close);

			if (labels.length === 0 || closeData.length === 0) {
				return;
			}

			const selectedStock = this.availableStocks.find(s => s.symbol === this.selectedStockSymbol);
			const stockLabel = selectedStock ? `${selectedStock.name} (${this.marketData.symbol})` : this.marketData.symbol;

			this.stockPerformanceChart = new Chart(ctx, {
				type: 'line',
				data: {
					labels,
					datasets: [
						{
							label: stockLabel,
							data: closeData,
							borderColor: this.chartColors[1],
							backgroundColor: this.chartColors[1] + '20',
							borderWidth: 2,
							fill: true,
							tension: 0.4,
						},
					],
				},
				options: {
					responsive: true,
					maintainAspectRatio: false,
					plugins: {
						legend: {
							display: true,
							position: 'top',
							labels: {
								color: '#cbd5e1',
								font: {
									size: 12,
								},
							},
						},
						tooltip: {
							mode: 'index',
							intersect: false,
							callbacks: {
								label: context => {
									const label = context.dataset.label || '';
									const value = (context.parsed.y ?? 0).toFixed(2);
									return `${label}: $${value}`;
								},
							},
						},
					},
					scales: {
						x: {
							ticks: {
								color: '#475569',
								maxRotation: 45,
								minRotation: 0,
							},
							grid: {
								display: false,
							},
						},
						y: {
							ticks: {
								color: '#475569',
								callback: value => `$${value}`,
							},
							grid: {
								color: 'rgba(148, 163, 184, 0.25)',
							},
						},
					},
					interaction: {
						mode: 'nearest',
						axis: 'x',
						intersect: false,
					},
				},
			});
		} catch (e) {
			console.error('Stock performance chart render failed', e);
			this.error = 'Chart konnte nicht gerendert werden.';
		}
	}

	private destroyChart(): void {
		if (this.stockPerformanceChart) {
			this.stockPerformanceChart.destroy();
			this.stockPerformanceChart = null;
		}
	}
}
