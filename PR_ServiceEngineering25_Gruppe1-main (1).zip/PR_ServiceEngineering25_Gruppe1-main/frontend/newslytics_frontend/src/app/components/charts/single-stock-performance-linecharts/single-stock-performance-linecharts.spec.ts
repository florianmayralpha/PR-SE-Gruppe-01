import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SingleStockPerformanceLinecharts } from './single-stock-performance-linecharts';

describe('SingleStockPerformanceLinecharts', () => {
  let component: SingleStockPerformanceLinecharts;
  let fixture: ComponentFixture<SingleStockPerformanceLinecharts>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SingleStockPerformanceLinecharts]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SingleStockPerformanceLinecharts);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
