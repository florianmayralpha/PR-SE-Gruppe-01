import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PerformanceLinechart } from './performance-linechart';

describe('PerformanceLinechart', () => {
  let component: PerformanceLinechart;
  let fixture: ComponentFixture<PerformanceLinechart>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PerformanceLinechart]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PerformanceLinechart);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
