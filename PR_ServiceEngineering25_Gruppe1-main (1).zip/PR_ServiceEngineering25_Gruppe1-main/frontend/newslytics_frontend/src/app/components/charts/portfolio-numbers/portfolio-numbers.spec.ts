import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PortfolioNumbers } from './portfolio-numbers';

describe('PortfolioNumbers', () => {
  let component: PortfolioNumbers;
  let fixture: ComponentFixture<PortfolioNumbers>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PortfolioNumbers]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PortfolioNumbers);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
