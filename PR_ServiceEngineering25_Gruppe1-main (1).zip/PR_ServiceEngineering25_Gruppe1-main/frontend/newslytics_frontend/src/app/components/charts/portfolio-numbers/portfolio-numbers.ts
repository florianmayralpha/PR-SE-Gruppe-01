import { Component, Input, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PortfolioChartsService } from '../../../services/portfolio-charts.service';
import { AuthService } from '../../../services/auth.service';
import { AggregatedPortfolioPerformanceResponse, PortfolioKPIs } from '../../../models/charts';

@Component({
  selector: 'app-portfolio-numbers',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './portfolio-numbers.html',
  styleUrl: './portfolio-numbers.scss',
})
export class PortfolioNumbers implements OnInit, OnChanges {
  @Input() selectedPortfolioId: number | null = null;

  loading = false;
  error: string | null = null;
  
  aggregatedData: AggregatedPortfolioPerformanceResponse | null = null;
  selectedPortfolioData: PortfolioKPIs | null = null;

  constructor(
    private portfolioChartsService: PortfolioChartsService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.loadData();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['selectedPortfolioId']) {
      this.updateSelectedPortfolioData();
    }
  }

  private loadData(): void {
    const userId = this.authService.currentUser?.id;
    if (!userId) {
      this.error = 'Benutzer nicht authentifiziert';
      return;
    }

    this.loading = true;
    this.error = null;

    this.portfolioChartsService.getAggregatedPortfolioPerformance(userId, {
      include_portfolios: true,
      include_positions: false
    }).subscribe({
      next: (data) => {
        this.aggregatedData = data;
        this.updateSelectedPortfolioData();
        this.loading = false;
      },
      error: (err) => {
        console.error('Error loading portfolio performance:', err);
        this.error = 'Fehler beim Laden der Portfolio-Daten';
        this.loading = false;
      }
    });
  }

  private updateSelectedPortfolioData(): void {
    if (!this.aggregatedData || !this.selectedPortfolioId) {
      this.selectedPortfolioData = null;
      return;
    }

    const portfolios = this.aggregatedData.portfolios || [];
    this.selectedPortfolioData = portfolios.find(p => p.portfolio_id === this.selectedPortfolioId) || null;
  }

  formatNumber(value: number | null | undefined): string {
    if (value === null || value === undefined) {
      return '-';
    }
    return new Intl.NumberFormat('de-DE', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  }

  formatPercent(value: number | null | undefined): string {
    if (value === null || value === undefined) {
      return '-';
    }
    const sign = value >= 0 ? '+' : '';
    return `${sign}${this.formatNumber(value)}%`;
  }

  getChangeClass(value: number | null | undefined): string {
    if (value === null || value === undefined) return '';
    return value >= 0 ? 'positive' : 'negative';
  }
}

