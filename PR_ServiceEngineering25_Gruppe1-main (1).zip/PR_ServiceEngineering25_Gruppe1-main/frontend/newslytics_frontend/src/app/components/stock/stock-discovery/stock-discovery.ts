import { CommonModule } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StockService } from '../../../services/stock.service';
import { ScreenerResult } from '../../../models/stock';

@Component({
  selector: 'app-stock-discovery',
  imports: [CommonModule],
  standalone: true,
  templateUrl: './stock-discovery.html',
  styleUrl: './stock-discovery.scss',
})
export class StockDiscovery implements OnInit {
  @Input() screenerType: string = 'most_actives';
  @Input() region: string = 'US';
  @Input() count: number = 6;

  title: string = '';
  stocks: ScreenerResult[] = [];
  loading = true;
  error: string | null = null;

  constructor(
    private stockService: StockService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadScreenerStocks();
  }

  private getGermanScreenerTitle(screenerType: string): string | null {
    const mapping: Record<string, string> = {
      day_gainers: 'Top-Gewinner',
      day_losers: 'Top-Verlierer',
      most_actives: 'Meistgehandelt',
      esg_leaders: 'ESG-Leader',
      growth_technology_stocks: 'Wachstums-Tech',
      undervalued_growth_stocks: 'Unterbewertete Wachstumsaktien',
      green_energy_stocks: 'Erneuerbare Energien',
      artificial_intelligence: 'Künstliche Intelligenz',
    };

    return mapping[screenerType] ?? null;
  }

  private loadScreenerStocks(): void {
    this.stockService.getScreenerStocks(this.screenerType, this.region, this.count).subscribe({
      next: (response) => {
        this.title = this.getGermanScreenerTitle(this.screenerType) ?? response.label;
        this.stocks = response.results;
        this.loading = false;
      },
      error: (err) => {
        console.error('Failed to load screener stocks:', err);
        this.error = 'Fehler beim Laden der Aktien';
        this.loading = false;
      }
    });
  }

  getChangeClass(changePercent: number | undefined): string {
    if (!changePercent) return '';
    return changePercent > 0 ? 'positive' : 'negative';
  }

  formatChange(changePercent: number | undefined): string {
    if (!changePercent) return 'N/A';
    const sign = changePercent > 0 ? '+' : '';
    return `${sign}${changePercent.toFixed(2)}%`;
  }

  formatPrice(price: number | undefined): string {
    if (!price) return 'N/A';
    return price.toFixed(2);
  }

  onStockClick(stock: ScreenerResult): void {
    this.router.navigate(['/stocks', stock.symbol]);
  }

  getCurrentDate(): string {
    const now = new Date();
    return now.toLocaleDateString('de-DE', { 
      day: '2-digit', 
      month: '2-digit', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  }

  generateChartPoints(changePercent: number | undefined): string {
    if (!changePercent) {
      return '0,12 20,12 40,12 60,12';
    }
    
    const isPositive = changePercent > 0;
    const startY = isPositive ? 18 : 6;
    const endY = isPositive ? 6 : 18;
    
    return `0,${startY} 20,${(startY + endY) / 2} 40,${(startY + endY) / 2} 60,${endY}`;
  }
}
