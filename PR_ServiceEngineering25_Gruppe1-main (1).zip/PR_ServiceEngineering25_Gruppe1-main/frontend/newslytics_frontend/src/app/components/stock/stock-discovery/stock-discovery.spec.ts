import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StockDiscovery } from './stock-discovery';

describe('StockDiscovery', () => {
  let component: StockDiscovery;
  let fixture: ComponentFixture<StockDiscovery>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StockDiscovery]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StockDiscovery);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
