import { CommonModule } from '@angular/common';
import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { StockService } from '../../../services/stock.service';
import { CompanyInfo } from '../../../models/stock';

@Component({
  standalone: true,
  selector: 'app-stock-description',
  imports: [CommonModule],
  templateUrl: './stock-description.component.html',
  styleUrl: './stock-description.component.scss',
})
export class StockDescriptionComponent implements OnChanges {
  @Input() symbol!: string;
  
  companyInfo: CompanyInfo | null = null;
  loading = false;
  error: string | null = null;

  constructor(private stockService: StockService) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['symbol'] && this.symbol) {
      this.loadCompanyInfo();
    }
  }

  private loadCompanyInfo(): void {
    this.loading = true;
    this.error = null;
    
    this.stockService.getCompanyInfo(this.symbol).subscribe({
      next: (response) => {
        this.companyInfo = response.company_data;
        this.loading = false;
      },
      error: (err) => {
        console.error('Failed to load company info:', err);
        this.error = 'Fehler beim Laden der Unternehmensinformationen';
        this.loading = false;
      }
    });
  }

  formatNumber(value: number | undefined): string {
    if (!value) return 'N/A';
    if (value >= 1e12) return `$${(value / 1e12).toFixed(2)}T`;
    if (value >= 1e9) return `$${(value / 1e9).toFixed(2)}B`;
    if (value >= 1e6) return `$${(value / 1e6).toFixed(2)}M`;
    return `$${value.toLocaleString()}`;
  }

  formatPercent(value: number | undefined): string {
    if (!value) return 'N/A';
    return `${(value * 100).toFixed(2)}%`;
  }
}
