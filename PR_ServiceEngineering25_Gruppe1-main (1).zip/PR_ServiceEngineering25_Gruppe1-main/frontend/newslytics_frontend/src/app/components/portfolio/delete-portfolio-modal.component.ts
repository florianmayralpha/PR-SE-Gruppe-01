import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  standalone: true,
  selector: 'app-delete-portfolio-modal',
  imports: [CommonModule],
  templateUrl: './delete-portfolio-modal.component.html',
  styleUrl: './delete-portfolio-modal.component.scss',
})
export class DeletePortfolioModalComponent {
  @Input({ required: true }) portfolioName = '';
  @Input() deleting = false;
  @Input() error: string | null = null;

  @Output() close = new EventEmitter<void>();
  @Output() confirm = new EventEmitter<void>();

  onOverlayClick(event: MouseEvent): void {
    if (this.deleting) {
      return;
    }

    if ((event.target as HTMLElement).classList.contains('modal-overlay')) {
      this.close.emit();
    }
  }
}
