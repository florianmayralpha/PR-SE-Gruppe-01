import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Output } from '@angular/core';

import { PortfolioService } from '../../services/portfolio.service';

interface ImportResult {
	message: string;
	portfolio_id: number;
	portfolio_name: string;
	created_transactions: number;
	skipped_transactions: number;
	errors?: Array<{ isin?: string; row_index?: number; error: string }>;
}

@Component({
	standalone: true,
	selector: 'app-import-portfolio-modal',
	imports: [CommonModule],
	templateUrl: './import-portfolio-modal.component.html',
	styleUrl: './import-portfolio-modal.component.scss'
})
export class ImportPortfolioModalComponent {
	@Output() close = new EventEmitter<void>();
	@Output() imported = new EventEmitter<ImportResult>();

	selectedFile: File | null = null;
	isDragOver = false;
	uploading = false;
	error: string | null = null;
	importResult: ImportResult | null = null;

	constructor(private portfolioService: PortfolioService) {}

	onDragOver(event: DragEvent): void {
		event.preventDefault();
		event.stopPropagation();
		this.isDragOver = true;
	}

	onDragLeave(event: DragEvent): void {
		event.preventDefault();
		event.stopPropagation();
		this.isDragOver = false;
	}

	onDrop(event: DragEvent): void {
		event.preventDefault();
		event.stopPropagation();
		this.isDragOver = false;

		const files = event.dataTransfer?.files;
		if (files && files.length > 0) {
			this.handleFile(files[0]);
		}
	}

	onFileSelected(event: Event): void {
		const input = event.target as HTMLInputElement;
		if (input.files && input.files.length > 0) {
			this.handleFile(input.files[0]);
		}
	}

	private handleFile(file: File): void {
		this.error = null;
		this.importResult = null;

		if (!file.name.endsWith('.csv')) {
			this.error = 'Nur CSV-Dateien sind erlaubt.';
			return;
		}

		this.selectedFile = file;
	}

	removeFile(event: Event): void {
		event.stopPropagation();
		this.selectedFile = null;
		this.error = null;
		this.importResult = null;
	}

	uploadFile(): void {
		if (!this.selectedFile || this.uploading) {
			return;
		}

		this.error = null;
		this.importResult = null;
		this.uploading = true;

		this.portfolioService.importPortfolioCsv(this.selectedFile).subscribe({
			next: (result) => {
				this.uploading = false;
				this.importResult = result;
				this.imported.emit(result);
				
				// Auto-close after 3 seconds if no errors
				if (!result.errors || result.errors.length === 0) {
					setTimeout(() => {
						this.close.emit();
					}, 3000);
				}
			},
			error: (err) => {
				this.uploading = false;
				this.error = err.error?.description || 'Import fehlgeschlagen. Bitte prüfe das CSV-Format.';
			}
		});
	}

	formatFileSize(bytes: number): string {
		if (bytes < 1024) {
			return bytes + ' B';
		} else if (bytes < 1024 * 1024) {
			return (bytes / 1024).toFixed(1) + ' KB';
		} else {
			return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
		}
	}

	onOverlayClick(event: MouseEvent): void {
		if ((event.target as HTMLElement).classList.contains('modal-overlay')) {
			if (!this.uploading) {
				this.close.emit();
			}
		}
	}
}
