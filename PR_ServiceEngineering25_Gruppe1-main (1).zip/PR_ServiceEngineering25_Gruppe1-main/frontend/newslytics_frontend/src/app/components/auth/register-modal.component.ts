import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { LoginRequest, RegisterRequest } from '../../models/auth';

@Component({
    standalone: true,
    selector: 'app-register-modal',
    imports: [CommonModule, FormsModule],
    templateUrl: './register-modal.component.html',
    styleUrls: ['./register-modal.component.scss']
})
export class RegisterModalComponent {
    @Output() close = new EventEmitter<void>();

    username = '';
    firstname = '';
    lastname = '';
    password = '';
    loading = false;
    error: string | null = null;

    constructor(private authService: AuthService) { }

    submit(): void {

        this.error = null;

        if (!this.paramValidate()) {
            return;
        }

        this.loading = true;

        const payload: RegisterRequest = {
            username: this.username,
            password: this.password,
            firstname: this.firstname,
            lastname: this.lastname
        };

        this.authService.register(payload).subscribe({
            next: () => {
                const loginPayload: LoginRequest = {
                    username: this.username,
                    password: this.password
                };

                this.authService.login(loginPayload).subscribe({
                    next: () => {
                        this.loading = false;
                        this.close.emit();
                    },
                    error: (err) => {
                        this.loading = false;
                        if (err?.status === 401) {
                            this.error = 'Konto wurde erstellt, aber die automatische Anmeldung ist fehlgeschlagen (Zugangsdaten ungültig).';
                            return;
                        }
                        this.error = 'Konto wurde erstellt, aber die automatische Anmeldung ist fehlgeschlagen.';
                    }
                });
            },
            error: (err) => {
                console.error('Register failed', err);
                this.loading = false;
                if (err?.status === 409) {
                    this.error = 'Dieser Benutzername ist bereits vergeben.';
                    return;
                }

                const message = String(err?.error?.message ?? err?.error ?? '').toLowerCase();
                if (message.includes('exists') || message.includes('already')) {
                    this.error = 'Dieser Benutzername ist bereits vergeben.';
                    return;
                }

                this.error = 'Registrierung fehlgeschlagen. Bitte versuche es erneut.';
            }
        });
    }

    private paramValidate(): boolean {
        const username = this.username.trim();
        const firstname = this.firstname.trim();
        const lastname = this.lastname.trim();
        const password = this.password;

        if (!username || !firstname || !lastname || !password) {
            this.error = 'Bitte alle Felder ausfüllen.';
            return false;
        }

        if (username.length < 3) {
            this.error = 'Der Benutzername muss mindestens 3 Zeichen lang sein.';
            return false;
        }

        if (password.length < 6) {
            this.error = 'Das Passwort muss mindestens 6 Zeichen lang sein.';
            return false;
        }

        if (firstname.length < 2 || lastname.length < 2) {
            this.error = 'Vor- und Nachname müssen mindestens 2 Zeichen lang sein.';
            return false;
        }

        return true;
    }


    onOverlayClick(event: MouseEvent): void {
        if ((event.target as HTMLElement).classList.contains('modal-overlay')) {
            this.close.emit();
        }
    }
}