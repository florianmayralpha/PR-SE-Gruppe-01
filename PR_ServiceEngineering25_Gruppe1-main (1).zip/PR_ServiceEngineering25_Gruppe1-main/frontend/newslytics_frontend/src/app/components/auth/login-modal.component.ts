import { CommonModule } from "@angular/common";
import { Component, Output, EventEmitter } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { LoginRequest } from "../../models/auth";
import { AuthService } from "../../services/auth.service";


@Component({
    standalone: true,
    selector: 'app-login-modal',
    imports: [CommonModule, FormsModule],
    templateUrl: './login-modal.component.html',
    styleUrls: ['./login-modal.component.scss']
})
export class LoginModalComponent {
    @Output() close = new EventEmitter<void>();

    username = '';
    password = '';
    loading = false;
    error: string | null = null;

    constructor(private authService: AuthService) { }

    submit(): void {

        this.error = null;

        if (!this.paramValidate()) {
            return;
        }

        this.loading = true;

        const payload: LoginRequest = {
            username: this.username,
            password: this.password
        };

        this.authService.login(payload).subscribe({
            next: () => {
                this.loading = false;
                console.log('Login success');
                this.close.emit();
            },
            error: (err) => {
                console.error('Login failed', err);
                this.loading = false;
                if (err?.status === 401) {
                    this.error = 'Benutzername oder Passwort ist falsch.';
                    return;
                }
                this.error = 'Anmeldung fehlgeschlagen. Bitte versuche es erneut.';
            }
        });
    }


    private paramValidate(): boolean {
        const username = this.username.trim();
        const password = this.password;

        if (!username || !password) {
            this.error = 'Bitte alle Felder ausfüllen.';
            return false;
        }

        if (username.length < 3) {
            this.error = 'Der Benutzername muss mindestens 3 Zeichen lang sein.';
            return false;
        }

        if (password.length < 6) {
            this.error = 'Das Passwort muss mindestens 6 Zeichen lang sein.';
            return false;
        }

        return true;
    }


    onOverlayClick(event: MouseEvent): void {
        if ((event.target as HTMLElement).classList.contains('modal-overlay')) {
            this.close.emit();
        }
    }
}