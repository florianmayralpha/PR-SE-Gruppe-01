import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { marked } from 'marked';
import { StockService } from '../../services/stock.service';
import { AIStockCandidate, AIStockSearchResponse } from '../../models/stock';

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  html: string;
  timestamp: string;
  searchResults?: AIStockCandidate[];
}

@Component({
  selector: 'app-category-stock-search-chatbot',
  imports: [CommonModule, FormsModule],
  standalone: true,
  templateUrl: './category-stock-search-chatbot.html',
  styleUrl: './category-stock-search-chatbot.scss',
})
export class CategoryStockSearchChatbot {
  @Input() portfolioId: number | null = null;

  messages: ChatMessage[] = [];
  inputValue = '';
  loading = false;
  error: string | null = null;
  isFullscreen = false;

  constructor(
    private stockService: StockService,
    private router: Router
  ) {
    this.initializeChat();
  }

  ngOnChanges(): void {
    this.initializeChat();
  }

  private initializeChat(): void {
    const portfolioNote = this.portfolioId 
      ? ' Aktien aus deinem ausgewählten Portfolio werden automatisch ausgeschlossen.'
      : '';
    
    const intro = `Ich helfe dir, Aktien nach Kategorien zu finden. Beschreibe mir, welche Art von Aktien du suchst (z.B. "defensive Dividenden-Aktien aus Europa" oder "Wachstumsaktien im Tech-Bereich").${portfolioNote}`;
    
    this.messages = [this.createMessage('assistant', intro)];
    this.inputValue = '';
    this.error = null;
    this.loading = false;
  }

  toggleFullscreen(): void {
    this.isFullscreen = !this.isFullscreen;
  }

  sendMessage(): void {
    const trimmed = this.inputValue.trim();
    if (!trimmed || this.loading) {
      return;
    }

    const userMessage = this.createMessage('user', trimmed);
    this.messages = [...this.messages, userMessage];
    this.inputValue = '';
    this.loading = true;
    this.error = null;

    this.stockService.searchStocksWithAI({
      prompt: trimmed,
      portfolio_id: this.portfolioId || undefined,
      limit: 7
    }).subscribe({
      next: (response: AIStockSearchResponse) => {
        const resultsText = this.formatSearchResults(response);
        const assistantMessage = this.createMessage(
          'assistant',
          resultsText,
          undefined,
          response.results
        );
        this.messages = [...this.messages, assistantMessage];
        this.loading = false;
      },
      error: (err) => {
        console.error('AI stock search failed:', err);
        this.loading = false;
        this.error = 'Aktiensuche konnte nicht durchgeführt werden.';
        const errorMessage = this.createMessage(
          'assistant',
          'Entschuldigung, es gab einen Fehler bei der Suche. Bitte versuche es erneut.'
        );
        this.messages = [...this.messages, errorMessage];
      }
    });
  }

  onStockClick(stock: AIStockCandidate): void {
    this.router.navigate(['/stocks', stock.symbol || stock.ticker]);
  }

  private formatSearchResults(response: AIStockSearchResponse): string {
    if (response.results.length === 0) {
      return 'Ich konnte leider keine passenden Aktien finden. Versuche eine andere Beschreibung.';
    }

    let text = `Ich habe **${response.results.length} Aktien** gefunden, die zu deiner Suche passen:\n\n`;
    
    response.results.forEach((stock, index) => {
      const name = stock.longName || stock.shortName || stock.symbol;
      const sector = stock.sector ? ` (${stock.sector})` : '';
      text += `${index + 1}. **${name}**${sector}\n`;
    });

    text += '\n*Klicke auf eine Aktie für weitere Details.*';
    return text;
  }

  private createMessage(
    sender: 'user' | 'assistant',
    text: string,
    timestamp?: string,
    searchResults?: AIStockCandidate[]
  ): ChatMessage {
    return {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      sender,
      text,
      html: this.renderMarkdown(text),
      timestamp: timestamp || new Date().toISOString(),
      searchResults
    };
  }

  private renderMarkdown(text: string): string {
    const raw = text ?? '';

    try {
      return marked.parse(raw, {
        gfm: true,
        breaks: true,
      }) as string;
    } catch {
      return this.escapeHtml(raw).replace(/\n/g, '<br>');
    }
  }

  private escapeHtml(text: string): string {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  get placeholder(): string {
    return 'Beschreibe die Art von Aktien, die du suchst...';
  }
}
