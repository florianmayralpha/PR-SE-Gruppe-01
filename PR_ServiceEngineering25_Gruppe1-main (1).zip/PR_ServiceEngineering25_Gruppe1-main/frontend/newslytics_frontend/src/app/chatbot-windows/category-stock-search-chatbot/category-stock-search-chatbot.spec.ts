import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CategoryStockSearchChatbot } from './category-stock-search-chatbot';

describe('CategoryStockSearchChatbot', () => {
  let component: CategoryStockSearchChatbot;
  let fixture: ComponentFixture<CategoryStockSearchChatbot>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CategoryStockSearchChatbot]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CategoryStockSearchChatbot);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
