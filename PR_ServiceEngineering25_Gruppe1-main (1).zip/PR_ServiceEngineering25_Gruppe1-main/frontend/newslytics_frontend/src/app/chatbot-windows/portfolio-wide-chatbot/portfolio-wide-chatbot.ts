import { CommonModule } from '@angular/common';
import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { marked } from 'marked';

import {
  PortfolioChatbotService,
  PortfolioChatMessage,
} from '../../services/portfolio-chatbot.service';

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  html: string;
  timestamp: string;
}

@Component({
  selector: 'app-portfolio-wide-chatbot',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './portfolio-wide-chatbot.html',
  styleUrl: './portfolio-wide-chatbot.scss',
})
export class PortfolioWideChatbot implements OnChanges {
  @Input() portfolioId: number | null = null;
  @Input() portfolioName: string | null = null;

  messages: ChatMessage[] = [];
  inputValue = '';
  loading = false;
  error: string | null = null;
  isFullscreen = false;
  private currentPortfolioKey: string | null = null;

  constructor(private chatbotService: PortfolioChatbotService) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['portfolioId'] || changes['portfolioName']) {
      this.resetForNewPortfolio();
    }
  }

  toggleFullscreen(): void {
    if (!this.portfolioId) {
      return;
    }

    this.isFullscreen = !this.isFullscreen;
  }

  sendMessage(): void {
    if (!this.portfolioId) {
      return;
    }

    const trimmed = this.inputValue.trim();
    if (!trimmed || this.loading) {
      return;
    }

    const userMessage = this.createMessage('user', trimmed);
    this.messages = [...this.messages, userMessage];
    this.inputValue = '';
    this.loading = true;
    this.error = null;

    const payload: PortfolioChatMessage[] = this.messages.map((message) => ({
      sender: message.sender,
      text: message.text,
    }));

    this.chatbotService
      .sendMessage({
        portfolioId: this.portfolioId,
        message: trimmed,
        history: payload,
      })
      .subscribe({
        next: (response) => {
          const assistantMessage = this.createMessage(
            'assistant',
            response.reply,
            response.timestamp,
          );
          this.messages = [...this.messages, assistantMessage];
          this.loading = false;
        },
        error: () => {
          this.loading = false;
          this.error = 'Konversation konnte nicht fortgesetzt werden.';
        },
      });
  }

  get placeholder(): string {
    if (!this.portfolioId) {
      return 'Bitte zuerst ein Portfolio auswählen.';
    }
    return 'Frage zum Portfolio stellen';
  }

  get title(): string {
    return this.portfolioName?.trim() || 'Portfolio Chat';
  }

  private resetForNewPortfolio(): void {
    const nextKey = this.portfolioId ? String(this.portfolioId) : null;
    if (nextKey === this.currentPortfolioKey) {
      return;
    }

    this.currentPortfolioKey = nextKey;
    this.inputValue = '';
    this.error = null;
    this.loading = false;
    this.isFullscreen = false;
    this.messages = [];

    if (this.portfolioId) {
      const intro = `Ich beantworte Fragen rund um dein Portfolio${this.portfolioName ? ` „${this.portfolioName}“` : ''}. Was möchtest du wissen?`;
      this.messages = [this.createMessage('assistant', intro)];
    }
  }

  private createMessage(sender: 'user' | 'assistant', text: string, timestamp?: string): ChatMessage {
    return {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      sender,
      text,
      html: this.renderMarkdown(text),
      timestamp: timestamp || new Date().toISOString(),
    };
  }

  private renderMarkdown(text: string): string {
    const raw = text ?? '';

    try {
      return marked.parse(raw, {
        gfm: true,
        breaks: true,
      }) as string;
    } catch {
      return this.escapeHtml(raw).replace(/\n/g, '<br>');
    }
  }

  private escapeHtml(text: string): string {
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
}
